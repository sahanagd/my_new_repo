function Body(){
    const body=<h1> i have to learn jsx</h1>
    return (<div> {body} </div>)
}
export default Body