function Footer(){
    const footer=<h1>please god bless me</h1>
    return (<div> {footer} </div>)
}
export default Footer