function Header(){
    const header=<h1>i have to work be confident</h1>
    return (<div> {header} </div>)
}
export default Header