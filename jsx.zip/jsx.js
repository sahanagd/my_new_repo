import Footer from "./footer";
import Body from "./body";
import Header from "./header"
function JSX() {
 return (<div> 
        <Header></Header>
        <Body></Body> 
        <Footer></Footer>
        </div>);
}
export default JSX